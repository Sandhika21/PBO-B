/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package list;

import java.util.HashMap;

public class Map {
    public static void main(String[] args) {
        HashMap<String, String> fruit = new HashMap<String, String>();
        
        Add(fruit);
        Display(fruit);
        Find(fruit, "Apple");
        Find(fruit, "Orange");
    }
    
    static void Add(HashMap<String, String> fruit){
        fruit.put("Apple", "Green");
        fruit.put("Banana", "Yellow");
    }
    
    static void Display(HashMap<String, String> fruit){
        for(HashMap.Entry<String, String> Fruit : fruit.entrySet()){
            System.out.println("Fruit : "+Fruit.getKey());
            System.out.println("Color : "+Fruit.getValue());
        }
    }
    
    static void Find(HashMap<String, String> fruit, String FRUIT){
        if(fruit.containsKey(FRUIT)){
            System.out.println("The "+FRUIT+" is "+fruit.get(FRUIT));
        }
        else{
            System.out.println("There is no "+FRUIT+" in the bowl");
        }
    }
}
