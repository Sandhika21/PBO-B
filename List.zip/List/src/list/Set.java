/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package list;

import java.util.HashSet;

public class Set {

    public static void main(String[] args) {
       HashSet<Coin> Bag = new HashSet<Coin>();
       Coin coin1 = new Coin(1);
       Coin coin2 = new Coin(2);
       Coin coin5 = new Coin(5);
       Coin coin10 = new Coin(10);
       Coin coin100 = new Coin(100);
       
       Bag.add(coin5);
       Bag.add(coin1);
       Bag.add(coin2);
       Bag.add(coin10);
       
       Find(Bag, coin1);
       Find(Bag, coin100);
       
       Display(Bag);
       
    }
     static void Find(HashSet<Coin> Bag, Coin coin){
         if(Bag.contains(coin)){
             System.out.println("There is a coin "+coin.GetDenomination());
         }
         else{
             System.out.println("There is no coin "+coin.GetDenomination());
         }
     }
    
    static void Display(HashSet<Coin> Bag){
        if(Bag.isEmpty()){
            System.out.println("There are no coins ");            
        }
        else{
            System.out.println("There are "+Bag.size()+" coins");
        }
    }
}
