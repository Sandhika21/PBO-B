/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package list;

import java.util.ArrayList;

public class List {
    public static void main(String[] args) {
        ArrayList<String> StudentID = new ArrayList();
        AddStudents(StudentID);
        DisplayStudents(StudentID);
        RemoveStudents(StudentID, "01234");
        DisplayStudents(StudentID);
        
    }
    
    static void AddStudents(ArrayList<String> StudentID){
        StudentID.add("01234");
        StudentID.add("12345");
        StudentID.add(2, "23456");
    }
    
    static void DisplayStudents(ArrayList<String> StudentID){
        for(String student : StudentID){
            System.out.println("ID : "+student);
        }
    }
    
    static void RemoveStudents(ArrayList<String> StudentID, String key){
        StudentID.remove(key);
    }
}
