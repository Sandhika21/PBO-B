/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package list;

import java.util.LinkedList;

public class Linked {
    public static void main(String[] args) {
        LinkedList<String> queue = new LinkedList<String>();
        queue.add("A");
        queue.add("B");
        queue.add("C");
        queue.add("D");
        
        LinkedList<String> stack = new LinkedList<String>();
        stack.push("D");
        stack.push("B");
        stack.push("C");
        stack.push("A");
        
        
        if(queue.c)
    }
    
}
