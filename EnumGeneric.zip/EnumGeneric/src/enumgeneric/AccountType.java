/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enumgeneric;

/**
 *
 * @author Lenovo
 */
public enum AccountType {
    SANDHIKA("Sandhika", "12345"),
    SAN("SAN", "23456");
    
    private String Nama;
    private String NoRek;
    
    private AccountType(String Nama, String NoRek){
        this.Nama = Nama;
        this.NoRek = NoRek;
    }
    
    public String getNama(){    
        return Nama;
    }
    
    public String getNo(){
        return NoRek;
    }
    public void Print(){
        System.out.println("Nama : "+getNama());
        System.out.println("No Rekening : "+getNo());  
    }
}
