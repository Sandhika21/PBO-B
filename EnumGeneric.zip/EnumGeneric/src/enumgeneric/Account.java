/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enumgeneric;

/**
 *
 * @author Lenovo
 */
public class Account<Q, W> {
    private Q No_Rek;
    private W Bunga;
    
    public void Set(Q No, W bunga){
        No_Rek = No;
        Bunga = bunga;
    }
    
    public Q getNR(){
        return No_Rek;
    }
    
    public W getB(){
        return Bunga;
    }
    
    
}
