/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package enumgeneric;

/**
 *
 * @author Lenovo
 */
public class EnumGeneric {
    public static void main(String[] args) {
        AccountType AT = AccountType.SANDHIKA;
        System.out.println("Nama : "+AT.getNama());
        System.out.println("No Rekening"+AT.getNo());
        
        Account<String, Integer> acc = new Account<>();
        Account<Integer, Double> acc1 = new Account<>();
        
        acc.Set("09876", 10);
        acc1.Set(45678, 12.5);
        
        System.out.println("No Rekening 1 : "+acc.getNR());
        System.out.println("Bunga 1 : "+acc.getB());
        System.out.println("No Rekening 2 : "+acc1.getNR());
        System.out.println("Bunga 2 : "+acc1.getB());
        
        Account1 ac1 = new Account1();
        String[] nama = {"Sandhika", "San"};
        Integer[] no = {10293, 39201};
        
        ac1.PrintArray(nama);
         ac1.PrintArray(no);
    }
}